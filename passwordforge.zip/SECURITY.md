# Security Policy

## Reporting a Vulnerability
If you discover a security issue, please open a private report (if your platform supports it)
or create an issue with minimal details and request a private channel.

## Scope
This project is defensive and does not perform attacks.
It should not log or store raw passwords.
