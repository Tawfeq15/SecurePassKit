# PasswordForge 🔐 (Password Toolkit API + CLI)

**A safe, defensive password toolkit** that can:
- **Check password strength** (entropy + pattern penalties + crack-time estimate)
- **Explain what to fix** (human-readable feedback)
- **Generate strong passwords** (random) and **memorable passphrases**
- **Suggest safer variants** of a base word (leet + structure + constraints)
- **Privacy-preserving reuse fingerprint** (HMAC token) — detect reuse **without storing passwords**
- **Report attestation** (SHA-256, optional Ed25519 signature) — tamper-evident results for demos/CI

> ⚠️ This project is for safety and learning. It does **not** hack or attack anything.

---

## ✨ Highlights

- **Evidence-based feedback**: every warning is tied to a clear reason (patterns, sequences, common words, etc.)
- **Policy engine**: `nist`, `strong`, `basic` presets + custom overrides
- **Privacy-first**: the API never stores raw passwords (only optional non-reversible tokens)
- **Cryptographic attestation**: hash/sign the report payload so it’s verifiable later
- **Two interfaces**: REST API (FastAPI/Swagger) + CLI

---

## 🚀 Quick Start — Start Here

### 1) Install

Open a terminal in the project folder.

**Windows (PowerShell)**
```powershell
py -m venv .venv
. .\.venv\Scripts\Activate.ps1
py -m pip install --upgrade pip
py -m pip install -r requirements.txt
```

**Linux/macOS**
```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install --upgrade pip
python3 -m pip install -r requirements.txt
```

### 2) Run the API

```bash
uvicorn main:app --host 0.0.0.0 --port 5005 --reload
```

### 3) Open Swagger UI

Open:
- `http://127.0.0.1:5005/docs`

---

## 🧪 Test with Postman

1) Method: **POST**  
2) URL:
```
http://127.0.0.1:5005/check
```
3) Body → raw → JSON:
```json
{
  "password": "P@ssw0rd123",
  "hints": ["salehabd", "uopsaleh6@gmail.com"],
  "mode": "offline",
  "policy_preset": "nist",
  "include_fingerprint": true,
  "include_attestation": true
}
```
You should get **200 OK** with `report`, `policy`, and `attestation`.

---

## 🧰 CLI Usage

After install (or `pip install -e .`):

```bash
passwordforge check "CorrectHorseBatteryStaple!2025" --preset nist --json
passwordforge gen --length 18
passwordforge phrase --words 4 --sep "-"
passwordforge suggest "saleh" --count 5 --length 14 --similarity 0.55
passwordforge serve --port 5005 --reload
```

---

## 🔐 Privacy-Preserving Reuse Fingerprint (HMAC)

If you set:
```bash
export FINGERPRINT_SECRET="some-long-random-secret"
```

Then `/check` returns:
- a short token (same password => same token)
- **non-reversible** without the secret

Useful for **reuse detection** without storing passwords.

---

## ✅ Report Attestation (SHA-256 / Ed25519)

Every `/check` response can include:
- `attestation.sha256` (deterministic hash over the report payload)

Optional signing:
```bash
export ATTEST_ED25519_PRIVATE_KEY_PEM="$(cat ed25519_private.pem)"
```

Verify later with:
- `POST /attestation/verify`

---

# عربي 🇵🇸🇯🇴

## شو بعمل البرنامج؟
هذا مشروع لفحص كلمات المرور وتوليد كلمات قوية. يقدر:
- يعطيك **تقييم قوة** + **نصائح تحسين**
- يولّد **Password عشوائي قوي**
- يولّد **Passphrase سهلة للحفظ**
- يقترح كلمات مرور **شبيهة بكلمة تختارها بس أكثر أمانًا**
- يعطيك **Fingerprint (HMAC)** لاكتشاف إعادة الاستخدام بدون تخزين الباسورد
- يعطيك **Attestation** (هاش/توقيع) عشان التقرير يكون “tamper-evident”

## تشغيل سريع
- شغّل السيرفر:
```bash
uvicorn main:app --host 0.0.0.0 --port 5005 --reload
```
- افتح Swagger:
`http://127.0.0.1:5005/docs`

## تجربة سريعة مع cURL
```bash
curl -X POST http://127.0.0.1:5005/check \
  -H "Content-Type: application/json" \
  -d '{"password":"P@ssw0rd123","hints":["saleh"],"policy_preset":"nist"}'
```

---

## License
MIT
